#include<stdio.h>
int main()
{
 int c =5;
 int *p =&c;
 printf("%d", *p); //5
 return 0;
 }
