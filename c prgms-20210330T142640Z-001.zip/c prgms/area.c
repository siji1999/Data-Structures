#include<stdio.h>
#define LENGTH  10
#define BREADTH 20
int main(){
int Area;
Area = LENGTH * BREADTH;
printf("Value of Area:%d",Area);
return 0;
}
