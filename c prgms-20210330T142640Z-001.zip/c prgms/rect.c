#include<stdio.h>
void main()
{
	int l,b,a,p;
	printf("enter length and breadth");
	scanf("%d%d",&l,&b);
	a=l*b;
	p=2*(l+b);
	printf("area is %d",a);
	printf("\nperimeter is %d",p);
}
