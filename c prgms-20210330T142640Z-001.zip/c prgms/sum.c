#include<stdio.h>
int main(){
int a = 5;
int b = 4;
int c;
c = a + b;
printf("value of c :%d",c);
return 0;
}
